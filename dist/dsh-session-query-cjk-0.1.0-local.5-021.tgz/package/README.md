# dsh-session-query-cjk（会话检索 · 中文分词 provider）

一句话：fork 官方 `@deepseek-ai/dsh-session-query-sqlite`，把索引的切词方式改成「中文按字切 + 短语查询 = 子串匹配」，同时把对账改成按会话增量、搜索不再内联对账。

- **包名 / 版本**：`dsh-session-query-cjk`（版本以 `package.json` 为准）
- **形态**：**普通插件**（无 `dsh.bundle`）——它必须挂在 `optional-session-search` 这个 **isolate 组**里才能成为 `ctx.sessionQuery`，所以由 profile 的 `cordis.patch.yml` 按名字引用，而不是自己 bundle 插入。
- **源码**：[源码/](源码/)（活源，唯一可改；`lib/index.js` 是 fork）
- **关联**：[dsh-session-search-async](../dsh-session-search-async/README.md)（异步入口，另一个独立件）

## 为什么需要它

官方 provider 用 FTS5 `unicode61`：连续汉字被当成**一个 token**，而查询又被整体包成短语。结果（2026-11-11 在本机 604 个会话、774 MB 索引上实测）：

| 查询 | 命中 |
|---|---|
| `"异步"`（被标点/加粗隔开时） | 77 |
| `"异步搜索"` | **0** |
| `"固件升级"` | **0** |
| `"会话插件"` | **0** |
| `"安全软件是否干预"` | **0** |

也就是说：中文只有在「恰好被标点/空格/`**` 隔开」时才搜得到，句中短语基本全灭。这是「经常没有有效结果」的另一半原因（前半截是每次搜索前 140 秒起的全量对账）。

## 它改了什么（与上游的四个差异）

1. **中文按字切 token**：入库前把每个 CJK 字符用 U+200B 隔开单独成 token，查询侧做同样变换再包短语。`"搜索插件"` 变成短语 `"搜 索 插 件"`，等价于**子串匹配**——「……搜索插件……」这种连续出现就能命中；片段渲染时把 U+200B 抹掉，模型/界面看到的仍是原文。
   - 分隔符必须满足两条：unicode61 视其为分隔符（私有区 U+E000 **不行**，实测被当成 token 字符），且不是 JS `\s` 意义上的空白（否则片段里会出现「异 步 搜 索」）。U+200B 是实测通过的那个。
   - 多词查询按空白切分后 **AND**：`"异步 插件"` = 两个词各自命中；上游把整串当短语，过于严格。
2. **按会话增量对账**：上游要求两遍全量清单完全一致才提交（期间任何会话在写就失败）。这里只列一遍清单，变化的会话**并发**读取，读完再对该会话 `stat()` 复核 revision；读期间被写的会话跳过、下一轮补。单个会话读坏也只跳过它。
3. **搜索不再内联对账**：上游每次 `searchSessions`/`searchEvents` 都先跑全量对账（工具每翻一页还再来一遍）。这里搜索只读现成索引，对账交给后台定时器；只有**空库**（刚装/换库）时首次搜索才同步建一次。
4. **独立索引库**：application id `1146308691`、schema 版本 `1`、库文件 `storages/session-search-cjk.db` 都与官方 `session-search.db` 分开。官方索引原样保留，回滚只需把 provider 行换回官方包。

保留的上游语义：过滤器、排序、游标代数、snippet 截断、只读派生索引、单进程单所有者、`openAt` 生命周期。

## 配置

| 键 | 默认 | 含义 |
|---|---|---|
| `path` | 必填 | 独立索引库路径（patch 里用 `dshHomePath('storages/session-search-cjk.db')`） |
| `openAt` | `startup` | `startup` / `first-search` / `never` |
| `refreshEnabled` | `true` | 后台对账开关 |
| `refreshIntervalMinutes` | `10` | 后台对账间隔；0 = 不做周期对账 |
| `refreshInitialDelaySeconds` | `30` | 启动后首次后台对账延迟 |
| `persistedReadConcurrency` | `4` | 并发读取变化会话的数量（首建索引时最有用） |
| 其余 | 同上游 | `journalMode` / `defaultLimit` / `maxLimit` / `snippetChars` / `readWindowMax` / `preparedSessionCacheSize` |

## 挂载方式

不是 bundle，由 profile 的 `cordis.patch.yml` 在 `optional-session-search` 组里引用：

```yaml
- id: optional-session-search
  config:
    - id: optional-session-query-cjk
      name: 'dsh-session-query-cjk'
      config:
        path: !!js dshHomePath('storages/session-search-cjk.db')
        openAt: startup
        refreshIntervalMinutes: 10
    - id: optional-tool-session-query
      name: '@deepseek-ai/dsh-tool-session-query'
      config:
        searchTimeoutMs: 120000
```

> 组内两行必须整份重述：patch 对 `config` 是整体替换；少写一行等于删掉它。
> 同时把 `dsh-session-index-refresh` 那行去掉——本插件自带后台对账，两个一起跑只会互相排队。

## 状态文件

后台每轮结果写到索引库同目录的 `session-search-cjk-status.json`：

```json
{ "at": "2026-11-11T10:00:00.000Z", "outcome": "ok", "durationMs": 42000 }
```

`outcome` 取值 `ok` / `failed`（`failed` 带 `error` 原文）。它是可选探针，写不进去不影响检索。

## 已知边界

- **查询是子串语义**：拆字短语要求连续出现（`"异步搜索"` 不命中「异步的搜索」）；多个词请用空格分开。
- **单字查询会命中很多**（等价于单字子串），这是刻意的取舍。
- **索引滞后**：后台每 10 分钟对账一次，最新会话可能还没进索引（搜索结果里最坏滞后一个周期）。
- **首建索引慢**：604 个会话首建约几分钟（受清单枚举 85 秒/遍 + 并发读限制），在后台跑；期间搜索会触发一次同步建库。
- **升级 dsh 后要重新对照上游**：`lib/index.js` 是 fork，升级后应 diff 官方 `dsh-session-query-sqlite` 并重新移植改动。

## 目录结构

```text
dsh-session-query-cjk\
├─ README.md
├─ 改动记录.md
├─ 改动理由.md
├─ 来源与校验.md
└─ 源码\
   ├─ package.json
   ├─ LICENSE（上游 MIT 原文）
   ├─ README.md（同本文件）
   ├─ lib\index.js（fork）
   └─ dev\（resolve 钩子 + 单测，不进包）
```

## 状态

- 2026-11-11：fork 完成，`node --check` 通过，`dev/test.mjs` 18/18 通过（中文子串、多词 AND、英文短语、片段渲染、纯标点拒绝）。
- 2026-11-11：隔离实例（3083）首建索引 222 秒，620 会话 / 20.9 万文档；中文命中 `异步搜索` 45、`固件升级` 26、`会话插件` 63（官方同一批数据为 0）。详见 `源码\证据\2026-11-11-隔离验收.md`。
- 打包完成：tgz 已进留档与运行件（SHA 见 `来源与校验.md`）；**尚未装进真实 profile**，装完需重启 dsh。
