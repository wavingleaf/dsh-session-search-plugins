# dsh-session-search-background（会话搜索后台入口）

一句话：给会话搜索加两个**后台工具**——`session_search_background` / `session_event_search_background`：前台立刻返回「已在后台开始」，后台复用官方实现跑完，再把结果作为一条 notice 消息投回当前会话（与子代理结算通知同一套机制）。

- **包名 / 版本**：`dsh-session-search-background`（版本以 `package.json` 为准）
- **本机状态**：源码与单测完成、tgz 已打包；**待装进真实 profile**
- **源码**：[源码/](源码/)（活源，唯一可改）
- **关联**：[dsh-session-query-cjk](../dsh-session-query-cjk/README.md)（分词插件，另一个独立件；本插件不依赖它也能工作）

## 为什么需要它

官方 `@deepseek-ai/dsh-tool-session-query` 的 `session_search` / `session_event_search` 是同步执行：

1. 每次调用都先做一遍全量索引对账（2026-11-04 本机实测：514 个会话列一遍持久化清单 ≈ 85 秒，一次对账两遍 ≈ 170 秒）；
2. 工具内部最多翻 5 页（每页 20 条、上限 100 条），**每页都重新对账**；
3. 对账在 `ctx.sessionQuery` 的串行队列里执行，两次搜索互相排队。

结果：一次搜索把整轮对话卡住 2–10 分钟，且经常以 `SESSION_QUERY_PERSISTENCE_FAILED` 结束——这就是「搜得特别慢、还经常没有结果、拖累沟通」的前半截。

## 它怎么工作

**不改官方包、不复制实现、不做同名遮蔽**：

1. 从 `ctx.tools.get('session_search')` 拿到官方工具定义，spread 后**换名**注册：
   - `session_search` → `session_search_background`
   - `session_event_search` → `session_event_search_background`
   - 描述 = 官方原文 + 一句 `Runs in the background and returns immediately; the results arrive later as a follow-up message.`
   - 参数 schema、输出 schema、`presentCall`、`timeoutMs` 全部沿用官方定义，零复制；
2. 前台只做参数校验，随后**立即返回**一句「后台已开始、结果稍后以消息送达、别重复调用」；
3. 后台直接调用**官方工具定义自己的 `execute`**（授权 = cwd 严格相等、过滤、翻页、排版都由官方负责），只换一个不随前台调用结束而取消的 signal；
4. 跑完用官方 `output.render()` 渲染，包成一条 `source.kind = 'plugin:dsh-session-search-background'` 的 user 消息投回该 agent：运行中 `steer`（下一步边界消费）、空闲 `followup`（新起一轮）——与 `dsh-subagent` 的结算通知同一语义；
5. 失败也投一条消息（带 code 与原文），模型不会永远等下去；
6. 另加一小段系统提示，告诉模型**优先用后台版**；`syncTools: 'deny'` 时还会用 `tools.restrict({deny})` 把两个同步工具从每个 agent 的工具集里摘掉，让后台版彻底取代旧入口。

三个读取/追踪工具（`session_trace`、`session_event_trace`、`session_event_read`）官方原样保留：它们不走索引、本来就快。

## 配置

| 键 | 默认 | 含义 |
|---|---|---|
| `timeoutMs` | `900000`（15 分钟） | 后台搜索上限；超时按失败投回 |
| `maxInflightPerAgent` | `3` | 同一 agent 同时允许几个后台搜索，超出婉拒 |
| `syncTools` | `keep` | `keep` = 官方同步工具保留（提示优先异步）；`deny` = 用 `tools.restrict` 对每个 agent 屏蔽这两个同步工具 |

## 已知边界

- **结果滞后**：工具调用与结果送达之间隔一次后台执行；模型下一步才看得到。
- **同一查询去重**：同 agent 同参数的搜索在跑时，再调用只返回「已在后台运行」，不会起第二份。
- **当前 provider 慢**：本插件只管「不阻塞」，不负责让索引变快；配合 [dsh-session-query-cjk](../dsh-session-query-cjk/README.md) 才是毫秒级。
- **提示章节**：官方系统提示里仍有一句「Use session_search …」（来自官方工具包），与本插件追加的章节并存；`deny` 模式下旧名字不可用，但那段旧提示无法从本插件里删除。
- **deny 模式的挂载时机**：靠 `agent/created` + `api-session/added` 给每个 agent 加限制；插件加载前就已存在的 agent 在 apply 时补挂。\n- **注册时机**：本插件是 bundle 的宿主条目，官方工具在 session-search 组的子条目里异步装载。apply 时官方工具可能还没就绪，此时会等 `tools/change` / agent 创建再补注册；进度写在 `$DSH_HOME\\storages\\session-search-background-status.json`（`phase`：`applied` / `waiting-for-official-tools` / `registered`）。

## 目录结构

```text
dsh-session-search-background\
├─ README.md
├─ 改动记录.md
├─ 改动理由.md
├─ 来源与校验.md
└─ 源码\
   ├─ package.json
   ├─ cordis.patch.yml
   ├─ README.md（同本文件）
   ├─ lib\index.js
   └─ dev\（resolve 钩子 + 单测，不进包）
```

## 状态

- 2026-11-11：源码完成，`node --check` 通过，`dev/test.mjs` **39/39** 通过（新名注册、描述追加、提示章节、立即返回、后台投递、去重、校验、错误、超时、并发上限、deny/keep、**官方工具晚于插件注册时补注册**）。
- tgz 已打包进留档与运行件（SHA 见 [来源与校验.md](来源与校验.md)）；**尚未装进真实 profile**，装完需重启 dsh。
